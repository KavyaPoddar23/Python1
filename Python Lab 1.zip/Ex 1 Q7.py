import math

def calculate_area(a, b, c):
    s = (a + b + c) / 2
    area = math.sqrt(s * (s - a) * (s - b) * (s - c))
    return area

def get_triangle_sides():
    while True:
        try:
            a = float(input("Enter the first side of the triangle: "))
            b = float(input("Enter the second side of the triangle: "))
            c = float(input("Enter the third side of the triangle: "))
            
            if a + b > c and a + c > b and b + c > a:
                return a, b, c
            else:
                print("The sides do not form a valid triangle. Please enter valid sides.")
        except ValueError:
            print("Invalid input. Please enter numerical values for the sides.")

print("Enter the sides for the first triangle:")
a1, b1, c1 = get_triangle_sides()

print("Enter the sides for the second triangle:")
a2, b2, c2 = get_triangle_sides()

area1 = calculate_area(a1, b1, c1)
area2 = calculate_area(a2, b2, c2)

# Calculate total area
total_area = area1 + area2

# Calculate contributions in percentage
contribution1 = (area1 / total_area) * 100 if total_area > 0 else 0
contribution2 = (area2 / total_area) * 100 if total_area > 0 else 0

print(f"\nArea of the first triangle: {area1:.2f}")
print(f"Area of the second triangle: {area2:.2f}")
print(f"Total area of both triangles: {total_area:.2f}")
print(f"Contribution of the first triangle: {contribution1:.2f}%")
print(f"Contribution of the second triangle: {contribution2:.2f}%")
