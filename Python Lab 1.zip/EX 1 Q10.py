def is_leap_year(year):
    """Return True if the given year is a leap year, else False."""
    return (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0)

def get_days_in_month(month, year=None):
    """Return the number of days in the given month (and year if needed)."""
    months_days = {
        "January": 31,
        "February": 28,  
        "March": 31,
        "April": 30,
        "May": 31,
        "June": 30,
        "July": 31,
        "August": 31,
        "September": 30,
        "October": 31,
        "November": 30,
        "December": 31
    }

    # Check for leap year
    if month == "February" and year is not None:
        if is_leap_year(year):
            return 29
        else:
            return 28

    return months_days.get(month, "Invalid month name")


def main():
    months = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ]
    
    month = input("Enter the month name: ").strip()
    
    if month not in months:
        print("Invalid month name.")
        return
    
    if month == "February":
        year = int(input("Enter the year: ").strip())
        days = get_days_in_month(month, year)
    else:
        days = get_days_in_month(month)
    
    print(f"The number of days in {month} is : {days}")

if __name__ == "__main__":
    main()
