numbers = [2, 4, 6, 8, 10]

# a) Write a Python program to sum all the items of the list
def sum_of_list(lst):
    return sum(lst)

sum_result = sum_of_list(numbers)
print(f"Sum of the list: {sum_result}")

# (b) Write a Python program to multiply all the items
def multiply_of_list(lst):
    result = 1
    for number in lst:
        result *= number
    return result

product_result = multiply_of_list(numbers)
print(f"Product of the list: {product_result}")

# (c) Write a Python program to get the largest number from a list
def max_of_list(lst):
    return max(lst)

max_result = max_of_list(numbers)
print(f"Largest number in the list: {max_result}")

# (d) Write a Python program to get the smallest number from a list
def min_of_list(lst):
    return min(lst)

min_result = min_of_list(numbers)
print(f"Smallest number in the list: {min_result}")

