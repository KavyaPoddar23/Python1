input_tuple = ("python", "learn", "includehelp")

result = [s[-1] for s in input_tuple]
print(result)
