# (a)
start, end = 1, 50

print("Even numbers and their squares in range(1, 50):")
for number in range(start, end):
    if number % 2 == 0: 
        print(f"Even number: {number}, Square: {number ** 2}")

# (b)
start, end = 1, 100

print("Even numbers and their squares in range(1, 100):")
for number in range(start, end):
    if number % 2 == 0:  
        print(f"Even number: {number}, Square: {number ** 2}")
