color_names = ["Black", "Red", "Maroon", "Yellow"]
color_codes = ["000000", "FF0000", "800000", "FFFF00"]

color_dicts = [{'colorName': name, 'colorCode': code}
        for name, code in zip(color_names, color_codes)]

for color_dict in color_dicts:
    print(color_dict)
