A = ['abc', 'xyz', 'aba', '1221']

def check_first_last_equal(s):
    return s[0] == s[-1] if len(s) > 0 else False

for index, item in enumerate(A):
    if isinstance(item, str) and check_first_last_equal(item):
        print(f"String: {item}, Index: {index}")

