def sum_of_digits(number):
    return sum(int(digit) for digit in str(number))

def reverse_number(number):
    return int(str(number)[::-1])

while True:
    try:
        num = int(input("Enter a four-digit number: "))
        if 1000 <= num <= 9999:
            break
        else:
            print("The number must be a four-digit number.")
    except ValueError:
        print("Invalid input. Please enter a valid four-digit number.")

# Calculate sum of digits
digit_sum = sum_of_digits(num)

# Calculate reverse of the number
reverse_num = reverse_number(num)

print(f"Sum of digits: {digit_sum}")
print(f"Reverse of the number: {reverse_num}")
